# Standard National Public School — launch checklist

## Changes made in this package
- Updated the academic session references from 2025–26 to 2026–27.
- Removed old dated notice claims and replaced them with current-information prompts so expired dates are not presented as current events.
- Updated the ticker to avoid stale announcements.
- Changed the enquiry form so it sends a request to FormSubmit and only shows a success message after the service responds.
- Added admin-panel architecture/security notes in `admin/README-ADMIN-SETUP.md`.

## Important limitations — do these before launch
- Staff names, qualifications, photos, facilities, hours and all contact details have not been independently verified. The school must approve them. Stock photos must not be presented as real staff portraits.
- The enquiry form uses FormSubmit. The first submission triggers an activation email to `Standardnational98@gmail.com`; open that email and approve the form before expecting delivery. Submit a test enquiry after activation. The form does not store enquiries in a school database.
- A secure no-code admin panel is NOT yet operational. GitHub Pages is static hosting; a safe admin panel needs a CMS, OAuth configuration and integration of CMS-managed content into the website. See `admin/README-ADMIN-SETUP.md`.
- A separate timetable for each class is not yet built into the public site; actual class schedules and teacher assignments must be supplied by the school.

## Exact GitHub Pages publishing steps
1. Extract this ZIP on your computer.
2. Open the existing GitHub repository for the school website.
3. Upload the contents of the extracted folder to the repository root. Ensure `index.html` is at the root, not inside an extra nested folder. Include the `admin` folder and this checklist.
4. Commit the files to the main branch.
5. In GitHub, open **Settings → Pages**. Under Build and deployment, select **Deploy from a branch**, choose `main` and `/ (root)`, then Save.
6. Wait for the Pages deployment and open the URL shown in Settings → Pages.
7. Test the site on a phone and desktop. Check every navigation link, phone link, email link and image.
8. Activate FormSubmit using the confirmation email, then submit a test enquiry using a test name/number. Confirm the email arrives before promoting the form publicly.
9. Verify all staff details, hours, fees, admissions statements, facilities and notices with school management. Remove any inaccurate statements/photos.
10. Do not call the site fully launch-ready until the CMS/admin login and class-wise timetable are implemented and tested.

## Form delivery notes
FormSubmit is a third-party service. Its first-use activation is required and spam protection may be applied. If activation is not completed or the service is unavailable, the website now shows a fallback message with the school's phone/email rather than falsely claiming the enquiry was delivered.
