# Secure no-code admin panel — setup required

This website is a static HTML site. GitHub Pages does not provide a secure server-side login or database by itself. Do not put GitHub access tokens or passwords in HTML/JavaScript.

Recommended approach: Decap CMS + a trusted OAuth backend, with content files committed to the GitHub repository. Before the CMS can safely edit the live website, the site must be refactored to render content from CMS-managed files (staff, notices, timetable data) rather than hard-coded HTML. Configure a real GitHub repository name and OAuth backend before enabling the admin route. This setup is intentionally not represented as already working.

## Content to manage in the CMS
- School settings: academic session, contact details and opening hours.
- Staff: name, designation, qualifications, subjects and approved photo.
- Notices: title, date, category and body; archive old notices rather than leaving expired notices live.
- Timetables: one record per class, with weekday, period, start/end time, subject, teacher and break rows.

## Required security checks
1. Use an OAuth backend from a trusted provider; never store a GitHub personal access token in the public site.
2. Restrict CMS access to approved school staff and use GitHub repository branch protection where practical.
3. Test edits on a staging branch before publishing.
4. Do not publish student personal information, private phone numbers or sensitive records.

A fully working CMS requires the actual GitHub repository owner/name and an OAuth provider configuration. GitHub Pages alone cannot safely provide this login/write capability.
