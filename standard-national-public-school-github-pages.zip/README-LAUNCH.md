# STANDARD NATIONAL PUBLIC SCHOOL — Launch preparation copy

Address: Dursuma, Manigam, Jammu & Kashmir, India

## Important before publishing
1. The official phone `9419630397` and email `Standardnational98@gmail.com` have been added to the contact links and enquiry email fallback. Phone links use India country code `+91`.
2. Admission and contact forms use `mailto:`: the visitor’s email application opens with a prepared message, and the visitor must press Send. This is not a server-side form service and enquiries are not stored by the website.
3. Confirm current admissions, classes, fees, timings, facilities, staff names/photos, and all school claims before sharing. Outdated 2025–26 notices were removed.
4. The staff console has been disabled because a password embedded in browser JavaScript is not secure and localStorage is not shared with school staff. Do not enable it without server-side authentication and a secure database.
5. The WhatsApp button remains disabled until the school confirms whether this phone number is also its official WhatsApp number.
6. Check image permissions and ensure photographs of children are published with appropriate parent/guardian consent.
7. Test the website on desktop and mobile before sharing it.

## Publish using GitHub Pages
1. Create/sign in to a GitHub account.
2. Create a **public** repository, for example `standard-national-public-school`. (GitHub Free generally requires a public repository for Pages.)
3. Upload `index.html` and `.nojekyll` to the repository root.
4. Open repository **Settings → Pages**. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/(root)`, then click **Save**.
5. Wait for the Pages deployment and open the URL shown in Settings → Pages. It will look like `https://YOUR-USERNAME.github.io/standard-national-public-school/`.
6. Test all navigation, phone/email links, mobile layout, and forms. A form is only ready once the official email is set; for a reliable form that doesn't depend on the visitor's email app, connect a reputable form backend before launch.

## Important privacy note
A GitHub Pages site is public. Do not upload student records, private contact lists, passwords, or other confidential information to the repository. GitHub Pages serves static files and does not provide a server-side database for this site.
